TensorBoard is a suite of web applications for inspecting and understanding
your TensorFlow runs and graphs.

Releases prior to 1.6.0 were published under the ``tensorflow-tensorboard`` name
and may be found at https://pypi.python.org/pypi/tensorflow-tensorboard.


